import numpy as np

def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum(axis=0)

def smooth(loss, cur_loss):
    return loss * 0.999 + cur_loss * 0.001

def print_sample(sample_ix, ix_to_char):
    txt = ''.join(ix_to_char[ix] for ix in sample_ix)
    txt = txt[0].upper() + txt[1:]  # viết hoa ký tự đầu tiên 
    print ('%s' % (txt, ), end='')
    
def get_sample(sample_ix, ix_to_char):
    txt = ''.join(ix_to_char[ix] for ix in sample_ix)
    txt = txt[0].upper() + txt[1:]  # viết hoa ký tự đầu tiên 
    return txt

def get_initial_loss(vocab_size, seq_length):
    return -np.log(1.0/vocab_size)*seq_length

def initialize_parameters(n_a, n_x, n_y):
    '''
    Khởi tạo các tham số với các giá trị ngẫu nhiên nhỏ
    
    Trả về:
    parameters -- từ điển Python chứa:
        Wax -- Ma trận trọng số nhân với đầu vào, mảng numpy có dạng (n_a, n_x)
        Waa -- Ma trận trọng số nhân với trạng thái ẩn, mảng numpy có dạng (n_a, n_a)
        Wya -- Ma trận trọng số liên quan đến trạng thái ẩn và đầu ra, mảng numpy có dạng (n_y, n_a)
        
        ba -- Sai số, mảng numpy có dạng (n_a, 1)
        by -- Sai số liên quan đến trạng thái ẩn và đầu ra, mảng numpy có dạng (n_y, 1)
    '''
    np.random.seed(1)
    Wax = np.random.randn(n_a, n_x)*0.01 # đầu vào tới ẩn
    Waa = np.random.randn(n_a, n_a)*0.01 # ẩn tới ẩn
    Wya = np.random.randn(n_y, n_a)*0.01 # ẩn tới đầu ra

    ba = np.zeros((n_a, 1)) # sai số ẩn
    by = np.zeros((n_y, 1)) # sai số đầu ra
    
    parameters = {'Wax': Wax, 'Waa': Waa, 'Wya': Wya, 'ba': ba,'by': by}
    
    return parameters

def rnn_step_forward(parameters, a_prev, x):
    
    Wax = parameters['Wax']
    Waa = parameters['Waa']
    Wya = parameters['Wya']
    ba = parameters['ba']
    by = parameters['by']

    a_next = np.tanh(np.dot(Wax, x) + np.dot(Waa, a_prev) + ba) 
    yt_pred = softmax(np.dot(Wya, a_next) + by) 
    
    return a_next, yt_pred

def rnn_step_backward(dy, gradients, parameters, x, a, a_prev):
    
    gradients['dWya'] += np.dot(dy, a.T)
    gradients['dby'] += dy

    # backprop vào h
    da = np.dot(parameters['Wya'].T, dy) + gradients['da_next'] 
    
    # backprop qua hàm tanh
    dtanh = (1 - a * a) * da 
    
    gradients['dba'] += dtanh
    gradients['dWax'] += np.dot(dtanh, x.T)
    gradients['dWaa'] += np.dot(dtanh, a_prev.T)
    gradients['da_next'] = np.dot(parameters['Waa'].T, dtanh)

    return gradients

def update_parameters(parameters, gradients, lr):

    parameters['Wax'] += -lr * gradients['dWax']
    parameters['Waa'] += -lr * gradients['dWaa']
    parameters['Wya'] += -lr * gradients['dWya']
    parameters['ba']  += -lr * gradients['dba']
    parameters['by']  += -lr * gradients['dby']
    return parameters

def rnn_forward(X, Y, a0, parameters, vocab_size = 27):
    
    x, a, y_pred = {}, {}, {}
    a[-1] = np.copy(a0)
    loss = 0
    
    for t in range(len(X)):
        
        # Đặt x[t] thành biểu diễn vector one-hot của ký tự thứ t trong X.
        # nếu X[t] == None, chúng tôi chỉ có x[t] = 0. Điều này được sử dụng để đặt đầu vào cho bước thời gian đầu tiên thành vector không. 
        x[t] = np.zeros((vocab_size, 1))
        if (X[t] != None):
            x[t][X[t]] = 1
        
        # Chạy một bước tiến của RNN
        a[t], y_pred[t] = rnn_step_forward(parameters, a[t-1], x[t])
        
        # Cập nhật mất mát bằng cách trừ đi thuật ngữ cross-entropy của bước thời gian này từ đó.
        loss -= np.log(y_pred[t][Y[t], 0])
    
    cache = (y_pred, a, x)
    
    return loss, cache

def rnn_backward(X, Y, parameters, cache):
    # Khởi tạo gradients thành một từ điển trống
    gradients = {}
    
    # Truy xuất từ cache và parameters
    (y_pred, a, x) = cache
    Waa, Wax, Wya, by, ba = parameters['Waa'], parameters['Wax'], parameters['Wya'], parameters['by'], parameters['ba']
    
    # mỗi cái phải được khởi tạo thành các vector zeros cùng kích thước với tham số tương ứng của nó
    gradients['dWax'], gradients['dWaa'], gradients['dWya'] = np.zeros_like(Wax), np.zeros_like(Waa), np.zeros_like(Wya)
    gradients['dba'], gradients['dby'] = np.zeros_like(ba), np.zeros_like(by)
    gradients['da_next'] = np.zeros_like(a[0])
    
    # Lan truyền ngược qua thời gian
    for t in reversed(range(len(X))):
        dy = np.copy(y_pred[t])
        dy[Y[t]] -= 1
        gradients = rnn_step_backward(dy, gradients, parameters, x[t], a[t], a[t-1])
    
    return gradients, a
